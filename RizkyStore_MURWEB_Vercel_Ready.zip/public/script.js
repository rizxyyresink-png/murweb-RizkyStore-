// ============================================================
// KONFIGURASI TEMPLATE — EDIT BAGIAN INI SEBELUM DIPAKAI/JUAL
// Nomor WhatsApp: format kode negara + nomor tanpa tanda + atau 0 awal.
const ADMIN_WA = "6200000000000"; // GANTI dengan nomor admin milikmu

// Edit nama, kategori, deskripsi, dan harga contoh sesuai produk asli.
// Harga menggunakan angka rupiah tanpa titik. Produk di bawah hanya contoh.
const products = [
 {id:"produk-1",name:"Produk Digital A",category:"chat",label:"KATEGORI A",icon:"A",iconClass:"whatsapp",description:"Deskripsi produk. Ganti dengan informasi yang akurat.",packages:[{name:"Paket Basic",price:5000},{name:"Paket Plus",price:10000}]},
 {id:"produk-2",name:"Produk Digital B",category:"social",label:"KATEGORI B",icon:"B",iconClass:"telegram",description:"Jelaskan manfaat dan ketentuan produk secara singkat.",packages:[{name:"Paket Basic",price:7000}]},
 {id:"produk-3",name:"Produk Digital C",category:"market",label:"KATEGORI C",icon:"C",iconClass:"shopee",description:"Produk contoh untuk katalog. Ubah sebelum dipublikasikan.",packages:[{name:"Paket 1",price:3000},{name:"Paket 2",price:6000}]}
];

let selectedProduct = null;
const rupiah = n => "Rp" + Number(n).toLocaleString("id-ID");
const grid = document.getElementById("productGrid");
function renderProducts(){
 const active=document.querySelector(".filter.active")?.dataset.filter||"all";
 const query=document.getElementById("searchInput").value.toLowerCase().trim();
 const filtered=products.filter(p=>(active==="all"||p.category===active)&&(p.name.toLowerCase().includes(query)||p.description.toLowerCase().includes(query)));
 grid.innerHTML=filtered.map(p=>`<article class="product-card"><div class="card-top"><div class="app-icon ${p.iconClass}">${p.icon}</div><span class="product-label">${p.label}</span></div><h3>${p.name}</h3><p>${p.description}</p><div class="card-bottom"><div class="price-from">MULAI DARI<strong>${rupiah(Math.min(...p.packages.map(x=>x.price)))}</strong></div><button class="order-btn" data-order="${p.id}">Pilih Paket ↗</button></div></article>`).join("");
 if(!filtered.length)grid.innerHTML='<p style="color:#aaa;font-size:13px">Produk tidak ditemukan. Coba kata kunci lain.</p>';
 grid.querySelectorAll("[data-order]").forEach(btn=>btn.addEventListener("click",()=>openOrder(btn.dataset.order)));
}
function openOrder(id){
 selectedProduct=products.find(p=>p.id===id);if(!selectedProduct)return;
 document.getElementById("modalProduct").textContent=selectedProduct.name+" — "+selectedProduct.description;
 document.getElementById("packageSelect").innerHTML=selectedProduct.packages.map((p,i)=>`<option value="${i}">${p.name} — ${rupiah(p.price)}</option>`).join("");
 document.getElementById("quantity").value=1;document.getElementById("notes").value="";updateTotal();
 document.getElementById("orderModal").classList.add("open");document.getElementById("orderModal").setAttribute("aria-hidden","false");document.body.style.overflow="hidden";
}
function closeOrder(){document.getElementById("orderModal").classList.remove("open");document.getElementById("orderModal").setAttribute("aria-hidden","true");document.body.style.overflow=""}
function currentPackage(){return selectedProduct?.packages[Number(document.getElementById("packageSelect").value)]}
function updateTotal(){const pack=currentPackage();const qty=Math.max(1,Math.min(20,Number(document.getElementById("quantity").value)||1));document.getElementById("quantity").value=qty;document.getElementById("totalPrice").textContent=rupiah((pack?.price||0)*qty)}
document.getElementById("packageSelect").addEventListener("change",updateTotal);
document.getElementById("quantity").addEventListener("input",updateTotal);
document.getElementById("minusQty").addEventListener("click",()=>{document.getElementById("quantity").value=Math.max(1,Number(document.getElementById("quantity").value)-1);updateTotal()});
document.getElementById("plusQty").addEventListener("click",()=>{document.getElementById("quantity").value=Math.min(20,Number(document.getElementById("quantity").value)+1);updateTotal()});
document.getElementById("modalClose").addEventListener("click",closeOrder);
document.getElementById("orderModal").addEventListener("click",e=>{if(e.target.id==="orderModal")closeOrder()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeOrder()});
document.getElementById("orderForm").addEventListener("submit",e=>{
 e.preventDefault();const pack=currentPackage();if(!selectedProduct||!pack)return;
 const qty=Number(document.getElementById("quantity").value)||1;const notes=document.getElementById("notes").value.trim()||"-";
 const message=`Halo Admin! Saya ingin memesan:\n\nProduk: ${selectedProduct.name}\nPaket: ${pack.name}\nHarga per paket: ${rupiah(pack.price)}\nJumlah: ${qty}\nEstimasi total: ${rupiah(pack.price*qty)}\nCatatan: ${notes}\n\nMohon konfirmasi ketersediaan dan total akhir.`;
 window.open(`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(message)}`,"_blank","noopener");closeOrder();
});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts()}));
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();renderProducts();
