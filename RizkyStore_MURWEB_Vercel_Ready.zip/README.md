# MURWEB Template — Katalog & Order Digital

Template website statis responsif yang diadaptasi dari project RizkyStore-Nokos. Cocok sebagai dasar katalog untuk produk digital, toko kecil, jasa kreatif, atau UMKM.

## Struktur
- `index.html` — halaman utama, katalog, FAQ, dan form order.
- `public/style.css` — desain responsif dark/red.
- `public/script.js` — daftar produk, filter, estimasi total, dan WhatsApp.
- `public/rizky-profile.png` — gambar contoh; ganti dengan gambar yang kamu punya hak pakainya.
- `vercel.json` — konfigurasi project statis.

## Cara edit lewat HP Android
1. Ekstrak ZIP menggunakan aplikasi pengelola file.
2. Buka folder project dengan editor kode Android.
3. Ubah teks brand pada `index.html`.
4. Buka `public/script.js`, lalu ganti `ADMIN_WA` dengan nomor WhatsApp admin dalam format internasional tanpa `+` (contoh format: `62812...`).
5. Edit array `products` di bagian atas `public/script.js`: nama, kategori (`chat`, `social`, `market`), label, deskripsi, paket, dan harga.
6. Ganti `public/rizky-profile.png` dengan aset milik sendiri jika ingin mengubah gambar. Pertahankan nama file atau sesuaikan `src` pada HTML.
7. Buka `index.html` lewat preview/browser dan tes pencarian, filter, form, jumlah, estimasi total, serta tombol WhatsApp.

## Deploy ke Vercel
1. Unggah project ke repository GitHub.
2. Import repository tersebut di Vercel.
3. Pilih framework `Other`; untuk website statis ini biasanya tidak perlu build command.
4. Deploy dan uji URL hasil deploy. Periksa pengaturan dan ketentuan paket hosting untuk penggunaan komersial.

## Sebelum dijual
- Ganti semua nama/teks placeholder dan nomor admin.
- Periksa seluruh tautan dan tampilan di layar HP.
- Pastikan gambar, font, ikon, dan aset pihak ketiga memiliki lisensi yang sesuai untuk distribusi komersial.
- Sertakan screenshot demo, panduan edit, dan lisensi pembeli yang jelas.
- Jangan menyatakan fitur pembayaran otomatis: project ini tidak memiliki backend, database, atau verifikasi pembayaran.
- Jangan simpan API secret, kata sandi, OTP, atau kredensial payment gateway pada kode frontend.
- Jangan menjual ulang aset/kode pihak ketiga yang lisensinya melarang redistribusi.

## Catatan fungsi
Form order membuka WhatsApp dengan detail pesanan. Harga adalah contoh dan harus disesuaikan. Template tidak memproses pembayaran atau menyimpan order ke database.

## Contoh lisensi yang bisa kamu sesuaikan
Pembeli boleh mengedit dan memakai template untuk proyek sendiri/klien sesuai paket lisensi yang dijual. Pembeli tidak boleh menjual ulang file template mentah atau mengklaim aset pihak ketiga sebagai miliknya. Tinjau dan sesuaikan ketentuan lisensi sebelum dipakai secara komersial.
